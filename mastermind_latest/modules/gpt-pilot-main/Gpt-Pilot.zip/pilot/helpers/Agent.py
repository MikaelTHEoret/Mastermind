class Agent:
    def __init__(self, role, project):
        self.role = role
        self.project = project