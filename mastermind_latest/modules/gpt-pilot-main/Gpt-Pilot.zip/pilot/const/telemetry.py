LARGE_REQUEST_THRESHOLD = 50000  # tokens
SLOW_REQUEST_THRESHOLD = 300  # seconds
LOOP_THRESHOLD = 3  # number of iterations in task to be considered a loop
