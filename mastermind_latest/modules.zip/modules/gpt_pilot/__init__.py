
# Import necessary components
from .utils import files, settings, task

def initialize():
    print("Gpt-Pilot module initialized")

def create_or_edit_file(file_path, content):
    if settings.DISABLE_RESTRICTIONS:
        with open(file_path, 'w') as f:
            f.write(content)
    else:
        # Handle restricted mode
        pass
    