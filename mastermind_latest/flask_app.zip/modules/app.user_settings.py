from flask import Flask
app = Flask(__name__)

# Initialize user settings (add this somewhere in app.py)
app.user_settings = {
    "allowed_actions": ["chat", "run_script", "modify_file"],  # Example allowed actions
    "permission_required": False,  # Example setting
    "system_message": "System message example"  # Example system message
}
