from flask import request, jsonify

def init_app(app):
    @app.route('/capture_input', methods=['POST'])
    def capture_input():
        data = request.json
        name = data.get('name')
        value = data.get('value')
        # Add your logic here
        return jsonify({'status': 'success', 'name': name, 'value': value})
