from flask import request, jsonify

def init_app(app):
    @app.route('/inject_code', methods=['POST'])
    def inject_code():
        data = request.json
        # Add your logic here
        return jsonify({'status': 'success', 'data': data})
