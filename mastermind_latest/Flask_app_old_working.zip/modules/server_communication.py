from flask import request, jsonify

def init_app(app):
    @app.route('/server_communication', methods=['POST'])
    def server_communication():
        data = request.json
        # Add your logic here
        return jsonify({'status': 'success', 'data': data})
