from flask import request, jsonify

def init_app(app):
    @app.route('/refresh_events', methods=['POST'])
    def refresh_events():
        data = request.json
        clid = data.get('clid')
        # Add your logic here
        return jsonify({'status': 'success', 'clid': clid})
