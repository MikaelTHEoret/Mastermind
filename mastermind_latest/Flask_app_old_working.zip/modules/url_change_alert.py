from flask import request, jsonify

def init_app(app):
    @app.route('/churl', methods=['GET'])
    def url_change_alert():
        pcid = request.args.get('pcid')
        url = request.args.get('url')
        # Add your logic here
        return jsonify({'status': 'success', 'pcid': pcid, 'url': url})
