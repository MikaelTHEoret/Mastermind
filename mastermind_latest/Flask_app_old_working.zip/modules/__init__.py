import os
import importlib

def load_modules(app):
    modules_dir = os.path.dirname(__file__)
    for root, _, files in os.walk(modules_dir):
        for file in files:
            if file.endswith(".py") and file != "__init__.py":
                module_name = os.path.splitext(file)[0]
                module_path = os.path.relpath(os.path.join(root, module_name), modules_dir)
                module_path = module_path.replace(os.path.sep, ".")
                module = importlib.import_module(f"modules.{module_path}")
                if hasattr(module, "init_app"):
                    module.init_app(app)
