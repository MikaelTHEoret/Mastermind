from flask import request, jsonify

user_settings = {
    "permission_required": True
}

def init_app(app):
    @app.route('/permissions/set_permission', methods=['POST'])
    def set_permission():
        permission = request.json.get('permission')
        user_settings["permission_required"] = permission
        return jsonify({'status': 'success', 'permission_required': permission})
    
    app.user_settings = user_settings
