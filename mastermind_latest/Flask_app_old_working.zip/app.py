﻿from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import openai
import os
import subprocess
from modules import load_modules

app = Flask(__name__)
CORS(app)

# Load secrets from secret.txt
def load_secrets():
    secrets = {}
    with open('secret.txt', 'r') as file:
        for line in file:
            if '=' in line:
                name, value = line.strip().split('=', 1)
                secrets[name] = value
    return secrets

secrets = load_secrets()
openai.api_key = secrets.get('OPENAI_API_KEY')

# Load modules
load_modules(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('input')
    
    # Check if action is allowed
    if "chat" not in app.user_settings["allowed_actions"] and app.user_settings["permission_required"]:
        return jsonify("Do you want to allow this action? [yes/no]")
    
    response = openai.ChatCompletion.create(
        model="gpt-4",  # Using GPT-4 model
        messages=[
            {"role": "system", "content": app.user_settings["system_message"]},
            {"role": "user", "content": user_input}
        ]
    )
    return jsonify(response.choices[0].message['content'].strip())

@app.route('/run_script', methods=['POST'])
def run_script():
    script_content = request.json.get('script')
    script_path = 'temp_script.py'
    
    if "run_script" not in app.user_settings["allowed_actions"] and app.user_settings["permission_required"]:
        return jsonify("Do you want to allow this action? [yes/no]")
    
    with open(script_path, 'w') as script_file:
        script_file.write(script_content)
    
    try:
        result = subprocess.run(['python', script_path], capture_output=True, text=True)
        return jsonify({'output': result.stdout, 'error': result.stderr})
    finally:
        os.remove(script_path)

@app.route('/modify_file', methods=['POST'])
def modify_file():
    file_path = request.json.get('file_path')
    modifications = request.json.get('modifications')
    
    if "modify_file" not in app.user_settings["allowed_actions"] and app.user_settings["permission_required"]:
        return jsonify("Do you want to allow this action? [yes/no]")
    
    with open(file_path, 'r') as file:
        content = file.read()
    
    modified_content = content + "\n" + modifications  # Simple example of modification
    
    with open(file_path, 'w') as file:
        file.write(modified_content)
    
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    app.run(debug=True)
