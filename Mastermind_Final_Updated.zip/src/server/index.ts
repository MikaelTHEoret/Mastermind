import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { WebSocket, WebSocketServer } from 'ws';
import { DatabaseManager } from '../core/database/DatabaseManager';
import { EventCoordinator } from '../core/EventCoordinator';

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });
const db = new DatabaseManager();
const events = new EventCoordinator();

// Middleware
app.use(cors());
app.use(express.json());

// WebSocket connection handling
wss.on('connection', (ws: WebSocket) => {
  console.log('Client connected');

  ws.on('message', async (message: string) => {
    try {
      const data = JSON.parse(message);
      await events.handleMessage(data);
      ws.send(JSON.stringify({ success: true }));
    } catch (error) {
      ws.send(JSON.stringify({ error: error.message }));
    }
  });

  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

// API Routes
app.post('/api/command', async (req, res) => {
  try {
    const { command } = req.body;
    const result = await events.processCommand(command);
    res.json({ success: true, result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export { app, server, wss };