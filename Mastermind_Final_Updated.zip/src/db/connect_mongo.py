
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi

# Database connection URI with password securely loaded
uri = "mongodb+srv://mik:Vq1vYnr0m6pcGFdD@pilot.vu5j6my.mongodb.net/?retryWrites=true&w=majority&appName=Pilot"

# Create a new MongoDB client
client = MongoClient(uri, server_api=ServerApi('1'))

# Confirm the connection
try:
    client.admin.command('ping')
    print("Connection to MongoDB successful!")
except Exception as e:
    print(f"Connection failed: {e}")
