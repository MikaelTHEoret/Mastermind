import { app, BrowserWindow, ipcMain } from 'electron';
import { FileSystemManager } from '../src/utils/fileSystem';

const fileSystem = new FileSystemManager();

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  if (process.env.NODE_ENV === 'development') {
    win.loadURL('http://localhost:5173');
  } else {
    win.loadFile('dist/index.html');
  }
}

app.whenReady().then(createWindow);

ipcMain.handle('request-permissions', () => {
  return fileSystem.requestPermissions();
});

ipcMain.handle('read-file', (_, path) => {
  return fileSystem.readFile(path);
});

ipcMain.handle('write-file', (_, path, content) => {
  return fileSystem.writeFile(path, content);
});

ipcMain.handle('list-files', (_, path) => {
  return fileSystem.listFiles(path);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});